#' Create lagged variables
#'
#' @description Function for creating variables with different lags, useful for forecasting models.
#' \code{character} or \code{factor} variables can not be lagged.
#' @param x \code{data.frame} or \code{vector} which contains the variables to be lagged
#' @param vars \code{character vector} with the name of the variables to be lagged.
#' If the variables can not be found in \code{x}, the function gives an error.
#' If \code{x} is a vector, \code{vars} is irrelevant.
#' @param lags variable which contain the number of lags to be created of each of the variables.
#' It can be a:
#' \itemize{
#'    \item \code{integer}. In this case, all the variables will be lagged from 1 to \code{lags}.
#'    \item \code{numeric vector}. In this case, the variables will be lagged from 1 to each \code{lag} of the respective place of the vector.
#'    \item \code{numeric list}. In this case, the variables will be lagged the \code{lags} defined by each component of the list.
#'    If \code{length(numeric list)} != \code{length(vars)}, the function gives an error.
#' }
#' if param \code{outclass} is "array", lags cannot be a list
#' See @examples for further information.
#' @param outclass \code{character} class of the output. It can be \code{data.frame}, and the function
#' returns a data.frame with all the variables with the lags, or \code{array}, and the function returns
#' a 3D-array, being the rows each of the samples, the columns each of the lags, and the third dimension
#' for each of the variables.
#' @param single \code{logical}, if \code{TRUE}, only the Lag of the value of the integer is calculated,
#' if \code{FALSE}, the Lags from 1 to integer are calculated
#' @return Depends on the param \code{outclass}, by default returns a \code{data.frame}
#' @examples
#' ## Example with an integer
#' df <- CreateLags(df, c("DEM_SP","WIND_SP"), 3)
#' # This will create 6 new variables:
#' #     - DEM_SP_Lag1, DEM_SP_Lag2, DEM_SP_Lag3
#' #     - WIND_SP_Lag1, WIND_SP_Lag2, WIND_SP_Lag3
#'
#' ## Example with a vector
#' df <- CreateLags(df, c("DEM_SP","WIND_SP"), c(1,5))
#' # This will create 4 new variables:
#' #     - DEM_SP_Lag1, DEM_SP_Lag5
#' #     - WIND_SP_Lag1, WIND_SP_Lag5
#'
#' ## Examples with a list
#' # Example with a list of integers
#' df <- CreateLags(df, c("DEM_SP","WIND_SP"), list(3,4))
#' # This will create 7 new variables:
#' #     - DEM_SP_Lag1, DEM_SP_Lag2, DEM_SP_Lag3
#' #     - WIND_SP_Lag1, WIND_SP_Lag2, WIND_SP_Lag3, WIND_SP_Lag4
#'
#' # Example with a list of vectors
#' df <- CreateLags(df, c("DEM_SP","WIND_SP"), list(c(1,5),c(2:4)))
#' # This will create 5 new variables:
#' #     - DEM_SP_Lag1, DEM_SP_Lag5
#' #     - WIND_SP_Lag2, WIND_SP_Lag3, WIND_SP_Lag4
#'
#' #' # Example with a list of integers & vectors
#' df <- CreateLags(df, c("DEM_SP","WIND_SP"), list(4,c(2,3,5)))
#' # This will create 7 new variables:
#' #     - DEM_SP_Lag1, DEM_SP_Lag2, DEM_SP_Lag3, DEM_SP_Lag4
#' #     - WIND_SP_Lag2, WIND_SP_Lag3, WIND_SP_Lag5
#'
#' # If df is a vector, the variables created are analogous
#' @export CreateLags
CreateLags <- function(x, vars, lags, outclass = "data.frame", single = FALSE) {
  # Create a data.frame if x is a vector
  if (is.vector(x)) {
    x.func <- data.frame(x)

  } else { # x is a data.frame
    x <- as.data.frame(x)
    # Check that all the variables are in the dataframe provided
    if (!all(vars %in% names(x))) {
      stop(paste0("\tThe var ",vars[!vars %in% names(df)]," is not in the dataframe\n"))
    }
    # Extract the variables of the dataframe
    if(length(vars) == 1){
      x.func <- data.frame(x[,vars])
      names(x.func) <- vars
    } else {
      x.func <- x[,vars]
    }
  }

  # Verify the arguments
  if(!outclass %in% c("data.frame","array")) {
    stop("class of the output must be data.frame or array")
  }
  if (!((is.numeric(lags) && (length(lags) == 1)) || is.list(lags) || (is.numeric(lags) && is.vector(lags)))) {
    stop("lags must be an integer, a vector or a list. See the examples section in ?CreateLags\n")
  }
  if(is.list(lags) && outclass == "array") {
    stop("if class of the output is array, lags cannot be a list")
  }
  # Create lags
  if ((is.numeric(lags) && (length(lags) == 1)) && !single) { # Case lags is an integer
    lags <- 1:lags # Create a vector of lags to be created
    x.lags <-CreateLags.single(x.func, lags)
    x <- cbind(x, x.lags)
  } else if (is.numeric(lags) && is.vector(lags)) { # Case lags is a vector
    x.lags <- CreateLags.single(x.func, lags)
    x <- cbind(x, x.lags)
  } else { # Case lags is a list
    # Check that the length is right
    if (length(lags) != ncol(x.func)) {
      stop("Number of lags defined does not match with number of variables to be lagged\n")
    }
    for (k in 1:length(lags)) {
      lag <- lags[[k]]
      if (length(lag) == 1) {
        lag <- 1:lag
      }
      x.lags <- CreateLags.single(x.func[k], lag)
      x <- cbind(x, x.lags)
    }
  }

  if (outclass == "data.frame") {
    # Return the data.frame with the lags
    return(x)
  } else {
    # Detect how many lags have been created for each variable
    posit_ <- sapply(gregexpr(pattern ='_',names(x.lags)),function(x){return(x[length(x)])})
    xlagsnames <- c()
    for(i in 1:ncol(x.lags)) {
      xlagsnames[i] <- substr(names(x.lags)[i],1,posit_[i]-1)
    }
    xlagsnames <- c(0,cumsum(table(xlagsnames)))
    # Join original data with lags in different data.frames
    x <- list()
    for(i in 2:length(xlagsnames)) {
      x[[i-1]] <- cbind(x.func[,i-1],x.lags[,(xlagsnames[i-1]+1):xlagsnames[i]])
      names(x[[i-1]])[1] <- names(x.func)[i-1]
    }
    # Transform the data into arrays
    x.array <- as.data.frame(do.call("cbind",x))
    x.array <- array(as.matrix(x.array), dim = c(nrow(x.array),ncol(x[[1]]),ncol(x.array)))
    return(x.array)
  }
}


CreateLags.single <- function(x.func, lags) {
  # Create lagged variables
  begin <- ncol(x.func) + 1
  for (j in 1:ncol(x.func)) {
    for (i in lags) {
      x.func[,(ncol(x.func)+1)] <- Hmisc::Lag(x.func[,j],
                                              shift = i)
      names(x.func)[ncol(x.func)] <- paste0(names(x.func)[j], "_Lag", as.character(i))
    }
  }
  x.lags <- x.func[,(begin:ncol(x.func))]
  return(x.lags)
}
