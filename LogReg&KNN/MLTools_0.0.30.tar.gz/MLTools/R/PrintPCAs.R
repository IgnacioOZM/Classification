#' Print the loadings of the PCAs
#'
#' @description Function to print the loadings of all the PCAs calculated.
#' @param PCAS PCA data calculated with \code{prcomp} of package \code{ggfortify}
#' @param interval \code{integer} number of loading plots plotted together.
#' By default is 3.
#' @param end \code{integer} last pca plotted. By default is the last PCA
#' @param begin \code{integer} first pca plotted. By default is the first PCA
#' @export PrintPCAsLoad
PrintPCAsLoad <- function(PCAS = NULL, interval = 3, end = NULL, begin = 1) {
  #Check for data
  if (is.null(PCAS) || !is.list(PCAS)) {
    stop("Enter correct PCAs data")
  }
  pcadata <- PCAS$rotation #Important data of the function
  if (is.null(end)) {
    # Check if only some graphics wants to be printed
    length_loop <- ncol(pcadata)
  } else{
    length_loop <- end
  }
  par(mfrow = c(interval, 1))
  for (i in begin:length_loop) {
    barplot(pcadata[, i], ylab = colnames(pcadata)[i])
    if (((i + 1 - begin) %% interval) == 0) {
      response <- readline(prompt = "Click any key to continue\n")
    }
  }
  par(mfrow = c(1, 1))
}

#' Print the components of the PCAs
#'
#' @description Function to print the components of all the PCAs calculated.
#' @param PCAS PCA data calculated with \code{prcomp} of package \code{ggfortify}
#' @param interval \code{integer} number of components plots plotted together.
#' By default is 3.
#' @param end \code{integer} last pca plotted. By default is the last PCA
#' @param begin \code{integer} first pca plotted. By default is the first PCA
#' @export PrintPCAsComp
PrintPCAsComp <- function(PCAS = NULL, interval = 3, end = NULL, begin = 1) {
    #Check for data
    if (is.null(PCAS) || !is.list(PCAS)) {
      print("Enter correct PCAs data")
    }
    pcadata <- PCAS$x #Important data of the function
    if (is.null(end)) {
      #Check if only some graphics wants to be printed
      length_loop <- ncol(pcadata)
    } else{
      length_loop <- end
    }
    par(mfrow = c(interval, 1))
    for (i in begin:length_loop) {
      plot(
        pcadata[, i],
        type = "l",
        ylab = colnames(pcadata)[i],
        xlab = "t",
        main = paste("Time series of component", colnames(pcadata)[i])
      )
      if (((i + 1 - begin) %% interval) == 0) {
        response <- readline(prompt = "Click any key to continue\n")
      }
    }
    par(mfrow = c(1, 1))
  }
