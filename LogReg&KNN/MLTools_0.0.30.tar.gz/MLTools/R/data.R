#' Data frame with 3 variables
#'
#' @description A dataset containing values to train and test classification models with a two-level output
#' @name plot2Dclass_2classes
#' @author José Portela González
#' @keywords data
#' @format A data frame with 1000 rows and 3 variables:
#' \describe{
#'   \item{X1}{numeric coordinate}
#'   \item{X2}{numeric coordinate}
#'   \item{Y}{output 2 levels YES and NO}
#' }
NULL


#' Data frame with 3 variables
#'
#' @description A dataset containing values to train and test classification models with a three-level output
#' @name plot2Dclass_3classes
#' @author Jaime Pizarroso Gonzalo
#' @keywords data
#' @format A data frame with 1500 rows and 3 variables:
#' \describe{
#'   \item{X1}{numeric coordinate}
#'   \item{X2}{numeric coordinate}
#'   \item{Y}{output 3 levels YES, MAYBE and NO}
#' }
NULL

#' Neural Network Training Model
#'
#' @description Neural Network training model that accepts number of iterations as training parameter
#' @name nnetICAI
#' @author José Portela González
#' @keywords nnet, model, train
NULL
