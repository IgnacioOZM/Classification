#' Profile reconstruction
#'
#' @description Plot the profile data based on the PCA data provided and compare it to the real data.
#' @param fdata \code{dataframe} original data
#' @param PCAs PCA data calculated with \code{prcomp} of package \code{ggfortify}
#' @param length \code{integer} number of components of fdata reconstructed
#' @param components \code{integer} number of pcas used for the reconstruction
#' @param xlab \code{character} lab of the x-axis
#' @param ylab \code{character} lab of the y-axis
#' @param end \code{integer} last pca plotted. By default is the last component
#' @param begin \code{integer} first pca plotted. By default is the first component
#' @export RecProfAll
RecProfAll <- function(fdata = NULL, PCAS = NULL, length = NULL, components = 3,
                       xlab = NULL, ylab = NULL, begin = 1, end = NULL) {
  if (is.null(fdata) || (length(fdata) != 1 && !is.list(fdata))) {
    stop("Enter correct series data")
  }
  if (ncol(fdata) > 1) {
    fdata <- as.data.frame(fdata)
  }
  if (is.null(PCAS) || (length(PCAS) != 1 && !is.list(PCAS))) {
    stop("Enter correct PCA data")
  }
  if (is.null(length)) {
    stop("Enter the length of the time series")
  }
  if(length > ncol(fdata)){
    length <- ncol(fdata)
  }
  if ((!is.null(xlab) &&
       !is.character(xlab)) || (!is.null(ylab) && !is.character(ylab))) {
    stop("Labs and title must be characters")
  }
  if ((components <= 0) || (components > ncol(PCAS$x))) {
    stop(paste(
      "Components must be positive and lower or equal than",
      ncol(PCAS$x)
    ))
  }
  if (is.null(end)) {
    end <- length(fdata)
  }
  for (i in begin:end) {
    plot(1:length, as.matrix(fdata[i, ]), type = "l", xlab = xlab, ylab = ylab)
    fdata.rec <- PCAS$center + (PCAS$x[i, 1:components] %*% t(PCAS$rotation[, 1:components])) *
      ifelse(PCAS$scale, PCAS$scale, 1)
    lines(1:length, fdata.rec[1, ], col = "red")
    legend(
      "topleft",
      title = paste("Component ", i),
      legend = c("Real", "Reconstruction"),
      col = c("black", "red"),
      lty = 1
    )
    response <- readline(prompt = "Click any key to continue\n")
  }
}
