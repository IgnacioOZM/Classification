#' Plot SOM Heatmap for variable
#'
#' @description Plot a heatmap for any variable from the data set "data".
#' If variable is 0, an interactive window will be provided to choose the variable.
#' If not, the variable in "variable" will be plotted.
#' It's based on the theory of Shame Lynn 13/1/2014.
#' @param som.model self-organising maps model of the data
#' @param data training data of SOM model
#' @param variable variable to be plotted
#' @export PlotHeatMap
PlotHeatMap <- function(som.model, data, variable = 0) {
  interactive <- TRUE

  data <- as.data.frame(data)

  while (interactive == TRUE) {
    if (variable == 0) {
      # show interactive window.
      color.by.var <- select.list(
        names(data),
        multiple = FALSE,
        graphics = TRUE,
        title = "Choose variable to color map by."
      )
      # check for user finished.
      if (color.by.var == "") {
        # if user presses Cancel - we quit function
        return(TRUE)
      }
      interactive <- TRUE
      color.variable <- data.frame(data[, color.by.var])

    } else {
      color.variable <- data.frame(data[, variable])
      color.by.var <- names(data)[variable]
      interactive <- FALSE
    }

    # if the variable chosen is a string or factor -
    # Get the levels and ask the user to choose which one they'd like.

    if (class(color.variable[, 1]) %in% c("character", "factor", "logical")) {
      # want to spread this out into dummy factors - but colour by one of those.
      temp.data <- dummies::dummy.data.frame(color.variable, sep = ".")
      chosen.factor <- select.list(
        names(temp.data),
        multiple = FALSE,
        graphics = TRUE,
        title = "Choose level of variable for colouring"
      )
      color.variable <- temp.data[, chosen.factor]
      rm(temp.data, chosen.factor)
      color.by <- color.variable
    } else {
      # impute the missing values with the mean.
      color.variable[is.na(color.variable[, 1]), 1] <-
        mean(color.variable[, 1], na.rm = TRUE)
      # color.by <- capVector(color.variable[,1])
      # color.by <- scale(color.by)
      color.by <- color.variable[, 1]
    }
    unit.colors <-
      aggregate(
        color.by,
        by = list(som.model$unit.classif),
        FUN = mean,
        simplify = TRUE
      )
    plot(
      som.model,
      type = "property",
      property = unit.colors[, 2],
      main = color.by.var,
      palette.name = CoolBlueHotRed
    )
  }
}

#' Return a color based on the value provided
#'
#' @param n \code{integer} number of colors
#' @param alpha \code{numeric} alpha parameter of the colors. Must be between 0 and 1.
#' @export CoolBlueHotRed
CoolBlueHotRed <- function(n, alpha = 1) {
  rainbow(n, end = 4 / 6, alpha = alpha)[n:1]
}
