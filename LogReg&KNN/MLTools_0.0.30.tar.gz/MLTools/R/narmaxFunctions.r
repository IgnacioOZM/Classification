#' Train a Nonlinear AutoRegressive Moving Average model with eXogenous inputs
#'
#' @description Function Train a Nonlinear AutoRegressive Moving Average model with eXogenous inputs
#' @param x \code{time series} Inputs of the model
#' @param y \code{time serie} Output of the model
#' @param nri \code{integer vector} number of delays to apply to the inputs
#' @param nre \code{integer} number of delays to apply to the output error
#' @param nh \code{integer} number of neurons in the hidden layer
#' @param nc \code{integer} number of iterations to train the network
#' @return narmax model
#' @examples
#' # Prbfn
#' # x is composed of two time series
#' # y is one time serie
#' # x and y must have the same length
#' narmax.fit <- train.narmax(x,y,
#'                            nri = c(3,4),
#'                            nre = 1,
#'                            nh = 5,
#'                            nc = 250)
#' @export train.narmax
train.narmax <- function(x, y, nri, nre, nh, nc = 100){

  ##Platform
  platform <- Sys.info()[['sysname']]

  ##Path settings
  wdpath <- getwd()
  libpath <- .libPaths()[1]
  exepath <- paste(libpath,"/MLTools/exec",sep = "")

  ##Data preparation
  #check NAs

  #Check for equal columns

  ##Model training
  #Set working directory
  setwd(exepath)
  #write data to text file
  write.table(x = cbind(x,y),file = "narmax.tr",row.names = FALSE,col.names = FALSE)
  #Create network configuration file
  fileConn<-file("narmax.net",open = "w")
  writeLines(c(sprintf("MPARMA (%d,%d,1)",ncol(x),nh),
               sprintf("NRI (%s)",paste(nri,collapse=",")),
               sprintf("NRE (%d)",nre),
               "learn",
               sprintf("NCO(%d)",nc),
               "FTRAIN(narmax.tr)",
               "FTEST (narmax.tr)"
               ), fileConn)
  close(fileConn)


  #Create call
  switch(platform,
         "Windows"={
           #prog="narmax.exe narmax"
           prog="ejecutaWin.bat"
           shell(prog)
         },
         "Darwin"={
           prog=sprintf("./narmax narmax")
           #system(paste("cd ",exepath," && " ,prog))
           system(prog)
         })

  #Read output file
  fout <- read.table(file = "narmax.out",header = FALSE)
  colnames(fout) <- c("fitted")
  #fout <- data.frame(fitted = c(0,fout$fitted))
  #Read res
  res <- read.table(file = "mpaux.res",header = FALSE)
  colnames(res) <- c("Train","Test")

  # Obtain weights
  txt <- readr::read_file("./narmax#.wgt")
  txt <- as.list(strsplit(txt,split = "\r\n")[[1]])
  txt <- txt[(which(txt == "* Pesos:")+1):length(txt)]
  wts <- suppressWarnings(sapply(txt, as.numeric))
  wts <- wts[!is.na(wts)]
  # noise_idx <- seq(from = 1, by = sum(nri)+nre+1, length.out = nh)
  # wts <- wts[!seq_len(length(wts)) %in% noise_idx]
  #Return to original working directory
  setwd(wdpath)

  #create model
  model <- list(x = x,
                y = y,
                nri = nri,
                nre = nre,
                nh = nh,
                nc = nc,
                out = fout,
                res = res,
                wts = wts
                )

  return(MLTools::NarmaxToMLP(model))
}

#' Predict values with a Nonlinear AutoRegressive Moving Average model with eXogenous inputs
#'
#' @description Function to predict values of a given data using a Nonlinear AutoRegressive Moving Average model with eXogenous inputs
#' @param model narmax model trained by the function above
#' @param x.new \code{time series} new inputs to use for prediction
#' @return vector with the predictions
#' @examples
#' y.tv <- predict.narmax(narmax, x.tv)
#' @export predict.narmax
predict.narmax <- function(model, x.new){

  ##Path settings
  # wdpath <- getwd()
  # exepath <- paste(wdpath,"/Run",sep = "")
  #
  # #Set working directory
  # setwd(exepath)
  #
  # ##Platform
  # platform <- Sys.info()[['sysname']]
  #
  # #Crea el fichero con los representantes a partir de los datos almacenados en el modelo
  # write.table(model$rep, "Prbfn.rep", row.names = FALSE,col.names = FALSE)
  # #Crea el fichero con los desviaciones a partir de los datos almacenados en el modelo
  # write.table(model$sig, "Prbfn.sig", row.names = FALSE,col.names = FALSE)
  # #Crea el fichero con los desviaciones a partir de los datos almacenados en el modelo
  # write.table(model$nvr, "Prbfn.nvr", row.names = FALSE,col.names = FALSE)
  # #Crea el fichero con los desviaciones a partir de los datos almacenados en el modelo
  # write.table(model$wa, "Prbfn.wa", row.names = FALSE,col.names = FALSE)
  # #Crea el fichero con los porcentajes a partir de los datos almacenados en el modelo
  # write.table(model$prc, "Prbfn.prc", row.names = FALSE,col.names = FALSE)
  #
  # #Crea el fichero de validacion
  # write.table(x.new, "Prbfn.tv", row.names = FALSE,col.names = FALSE)
  #
  # switch(platform,
  #        "Windows"={
  #          prog=sprintf("prbfnii_w_fdp %s %d %d 0 %d 0 - - %s.tv",
  #                       "Prbfn",ncol(x.new),model$nh,model$nc,"Prbfn")
  #          shell(prog)
  #        },
  #        "Darwin"={
  #          prog=sprintf("./prbfnii_w_fdp %s %d %d 0 %d 0 - - %s.tv",
  #                       "Prbfn",ncol(x.new),model$nh,model$nc,"Prbfn")
  #          system(paste("cd ",exepath," && " ,prog))
  #        })
  #
  #
  # #Incluimos el representante asociado a cada vector de datos
  # #Read output file
  # fout <- read.table(file = "Prbfn.out",header = FALSE)
  # fout <- fout[,1:3]
  # colnames(fout) <- c("logprob","vercual","repasoc")
  # fout$repasoc <- fout$repasoc + 1
  #
  # #Return to original working directory
  # setwd(wdpath)
  #
  #
  # return(fout)
}

#' Convert a NARMAX model to an R-like model list
#'
#' @description Convert the NARMAX model created by train.narmax to an R-like mlp model
#' @param narmax narmax model created by train.narmax
#' @return narmax R-like model
#' @export NarmaxToMLP
NarmaxToMLP <- function(narmax) {
  # Load necessary functions
  add.net <- function(net, from, to)
  {
    nconn <- net$nconn
    conn <- net$conn
    for(i in to){
      ns <- nconn[i+2L]
      cadd <- from
      if(nconn[i+1] == ns) cadd <- c(0,from)
      con <- NULL
      if(ns > 1L) con <- conn[1L:ns]
      con <- c(con, cadd)
      if(length(conn) > ns) con <- c(con, conn[(ns+1L):length(conn)])
      for(j in (i+1L):net$nunits) nconn[j+1L] <- nconn[j+1L]+length(cadd)
      conn <- con
    }
    net$nconn <- nconn
    net$conn <- con
    net
  }
  norm.net <- function(net)
  {
    n <- net$n; n0 <- n[1L]; n1 <- n0+n[2L]; n2 <- n1+n[3L];
    if(n[2L] <= 0) return(net)
    net <- add.net(net, 1L:n0,(n0+1L):n1)
    add.net(net, (n0+1L):n1, (n1+1L):n2)
  }
  createcoefnames <- function(xnames,yname,lags){
    nams <- xnames
    for (i in 1:length(xnames)) {
      if (lags[i]>1){
        for (j in 1:(lags[i]-1)) {
          nams[length(nams)+1]<-paste(xnames[i],paste0("Lag",as.character(j)),sep="_")
        }
      }

    }
    if (lags[i+1]>0){
      for (j in 1:lags[i+1]) {
        nams[length(nams)+1]<-paste(yname,paste0("Lag",as.character(j)),sep="_")
      }
    }
    nams
  }
  # Create data.frame of results
  res <- data.frame(init = numeric(1)); res$init <- NULL
  for(i in 1:length(narmax$nri)){res[,paste("nri",names(narmax$x)[i],sep="_")]<-narmax$nri[i]}
  res$nre <- narmax$nre;res$nh <- narmax$nh;res$nc <- narmax$nc
  res <- cbind(res,as.data.frame(forecast::accuracy(narmax$y,narmax$out$fitted)))
  # Create final model
  net <- NULL
  net$n <- c(sum(narmax$nri) + narmax$nre,
             narmax$nh,
             dim(as.data.frame(narmax$y))[2L])
  net$nunits <- as.integer(1L + sum(net$n))
  net$nconn <- rep(0, net$nunits+1L)
  net$conn <- numeric(0L)
  net <- norm.net(net)
  net$nsunits <- net$nunits - 1
  net$entropy <- FALSE
  net$softmax <- FALSE
  net$censored <- FALSE
  net$wts <- narmax$wts
  net$fitted.values <- narmax$out$fitted
  net$residuals <- narmax$y - narmax$out$fitted
  net$coefnames <- createcoefnames(names(narmax$x),"y",c(narmax$nri,narmax$nre))
  net$xNames <- net$coefnames
  net$yNames <- "y"
  narmax$wts <- NULL
  # Create narmax model based on previous
  narmax.fit <- list(method = "narmax",
                     modelInfo = list(label = "NARMAX",
                                      library = "MLTools",
                                      loop = NULL,
                                      type = "Regression",
                                      parameters = data.frame(parameter = c("nri","nre", "nh", "nc"),
                                                              class = rep("numeric",4),
                                                              label = c("Input lags",
                                                                        "Output lags",
                                                                        "# Neurons in hidden layer",
                                                                        "Iterations"))
                     ),
                     modelType = "Regression",
                     results = res,
                     pred = data.frame(pred=narmax$out$fitted,obs=narmax$y),
                     trainingData = data.frame(.outcome = narmax$y, narmax$x),
                     finalModel = net,
                     perfnames = names(as.data.frame(forecast::accuracy(narmax$y,narmax$out$fitted))),
                     coefnames = createcoefnames(names(narmax$x),"y",c(narmax$nri,narmax$nre)),
                     res = narmax$res,
                     narmax = narmax)
  class(narmax.fit) <- "NARMAX"
  return(narmax.fit)
}
