nnetarCaret <- list(type = 'Regression',
               library = 'forecast',
               loop = NULL)
prm <- data.frame(parameter = c('size','decay','p','P'),#'xlags', 'xlags_seas'),
                  class = c(rep('numeric',4)),#, 'character', 'character'),
                  label = c('#Hidden Units', "Weight Decay", "Output Lags", "Seasonal Output Lags")) #, "Input Lags", "Seasonal Input Lags"))
nnetarCaret$parameters <- prm
nnetarGrid <- function(x, y, len = NULL, search = "grid") {
  library(forecast)
  # ninputs <- ncol(x)
  # repVector <- function(x, nrepeats) {
  #   df <- data.frame(x)
  #   if (nrepeats > 1) {
  #     for (i in 2:nrepeats){
  #       df[,i] <- x
  #     }
  #   }
  #   df
  # }
  if (search == 'grid') {
    out <- expand.grid(
      size = seq(10, 30, length.out = 3),
      decay = 10 ^ seq(-5, -1, length.out = 3),
      p = seq(1, 3),
      P = 1
      # ,
      # xlags = apply(expand.grid(repVector(seq(1, 3), ninputs)), 1, paste, collapse=','),
      # xlags_seas = apply(expand.grid(repVector(1, ninputs)), 1, paste, collapse=',')
    )
  } else {
    out <- expand.grid(
      size = sample(seq(10, 50, length.out = 9), 3, replace = TRUE),
      decay = sample(10 ^ seq(-5, -1, length.out = 9), 3, replace = TRUE),
      p = sample(seq(1, 10, length.out = 10), 3, replace = TRUE),
      P = 1
      # ,
      # xlags = apply(expand.grid(repVector(sample(seq(1, 10, length.out = 10), 3, replace = TRUE), ninputs)), 1, paste, collapse=','),
      # xlags_seas = apply(expand.grid(repVector(1, ninputs)), 1, paste, collapse=',')
    )
  }
  out
}
nnetarCaret$grid <- nnetarGrid
nnetarFit <- function(x, y, wts, param, lev, last, weights, classProbs, frequency, ...) {
  forecast::nnetar(
    ts(y, frequency = frequency),
    xreg = x,
    p = param$p,
    P = param$P,
    size = param$size,
    decay = param$decay,
    ...
  )
}
nnetarCaret$fit <- nnetarFit
nnetar_prob <- function(modelFit, newdata, preProc = NULL, submodels = NULL,...) {
  forecast::nnetar(
    y,
    xreg = x,
    p = param$p,
    P = param$P,
    size = param$size,
    decay = param$decay,
    trace = TRUE,
    ...
  )
}
nnetarCaret$prob <- nnetar_prob
nnetarPred <- function(modelFit, newdata, preProc = NULL, submodels = NULL, ...) {
  as.vector(forecast(modelFit,  xreg = newdata, ...)$mean)
}
nnetarCaret$predict <- nnetarPred
nnetarSort <- function(x) {
  x[order(x$size, x$decay, x$p, x$P),]
}
nnetarCaret$sort <- nnetarSort 
nnetarCaret$varImp <- function(object, ...) {
  imp <- caret:::GarsonWeights(object, ...)
  if(ncol(imp) > 1) {
    imp <- cbind(apply(imp, 1, mean), imp)
    colnames(imp)[1] <- "Overall"
  } else {
    imp <- as.data.frame(imp)
    names(imp) <- "Overall"
  }
  if(!is.null(object$xNames)) rownames(imp) <- object$xNames
  imp
}
nnetarCaret$predictors <- function(x, ...) if(hasTerms(x)) predictors(x$terms) else NA
nnetarCaret$levels <- function(x) x$lev
nnetarCaret$tags <- c("Neural Network", "L2 Regularization","Accepts Case Weights")