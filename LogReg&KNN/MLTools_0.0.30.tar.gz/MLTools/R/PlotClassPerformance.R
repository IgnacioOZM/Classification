#' Plot the performance of a given class
#'
#' @description Function for plotting the performance of classificate a given class in a classification
#' problem. If the class is not given, an interactive list is displayed in order that the user select
#' one of the classes of the output.
#' \itemize{
#'    \item If it is a binary classification problem:
#'    \itemize{
#'       \item Plot 1 with an xyplot of the class \code{selclass}
#'       \item Plot 2 with two histograms of the classification probabilities of the class \code{selclass}
#'       \item Plot 3 with the ROC curve and probabilities plot of the class \code{selclass}
#'       \item Returns the AUC of the class \code{selclass}
#'    }
#'    \item If it is a multiclass classification problem:
#'    \itemize{
#'       \item Plot 1 with an xyplot of the class \code{selclass}
#'       \item Plot 2 with two histograms of the classification probabilities of the class \code{selclass}
#'       \item Returns the multi-class AUC of every class returned by \code{multiclass.roc()} of \code{pROC} package.
#'    }
#'  }
#' @param Y Vector with the output classification variable
#' @param prob.est Estimated probabilities of the model for the classification of the data
#' @param selClass \code{character}, level of the output variable to be analyzed
#' @examples
#' PlotClassPerformance(fdataTR_eval$Y, fdataTR_eval$lda_prob, selClass = "YES")
#' @export PlotClassPerformance
PlotClassPerformance <- function(Y, prob.est, selClass = NULL) {
  # Check selclass
  if (is.null(selClass)) {
    selClass <- select.list(levels(Y),
                            multiple = FALSE,
                            graphics = TRUE,
                            title = "Choose level to be analyzed")
  }

  # Use different plots in case the output has two levels
  if (nlevels(Y) == 2) {
    # Selected class
    # Check probabilities
    if (ncol(prob.est) != 1){
      prob.est <- prob.est[,selClass]
    }

    # Calibration plot
    # Use cuts for setting the number of probability splits
    df <- data.frame(Y, prob.est)
    calPlotData <- caret::calibration(Y ~ prob.est, data = df, class = selClass, cuts = 6)
    P1 <- lattice::xyplot(calPlotData, auto.key = list(columns = 2),
                 main = "Plot 1/3: Calibration plot")
    print(P1)

    # Histogram comparison
    P2 <- ggplot2::ggplot(df) +
      ggplot2::geom_histogram(ggplot2::aes(x = prob.est, fill = Y), bins = 15) +
      ggplot2::facet_wrap(~Y) +
      ggplot2::labs(x = paste("Probability of Class ", selClass), title = "Plot 2/3: Probability histograms")
    print(P2)

    # Create a 2 by 1 matrix of plots
    par(mfrow = c(1, 2),oma = c(0, 0, 2, 0))
    pred <- ROCR::prediction(prob.est, Y,
                             label.ordering = levels(Y)[order(levels(Y) %in% selClass, decreasing = FALSE)])
    perf <- ROCR::performance(pred, "tpr", "fpr")
    ROCR::plot(perf, avg = "threshold", colorize = T, lwd = 3,
         coloraxis.at = seq(0, 1, by = 0.2),
         main = "ROC curve")
    grid()

    perf <- ROCR::performance(pred, "acc")
    ROCR::plot(perf, lwd = 3, col = 'blue',
         main = "Accuracy across the range of possible cutoffs")
    grid()
    title("Plot 3/3: ROC curves", outer=TRUE)

    # Restore par
    par(mfrow = c(1, 1))

    # Print auc
    print(paste("Area under the ROC curve (auc): ", ROCR::performance(pred, "auc")@y.values[[1]]))

  } else {

    # Multiclass AUC
    for(i in 1:length(levels(Y))){
      auc <- as.numeric(pROC::multiclass.roc(response = ordered(Y), predictor = prob.est[, i])$auc)
      cat("Multi-class area under the curve for class ", levels(Y)[i],":", auc, "\n")
    }

    # Selected class
    # Check probabilities
    if (ncol(prob.est) != 1){
      prob.est <- prob.est[,selClass]
    }

    plotlist <- list()
    # Calibration plot
    # Use cuts for setting the number of probability splits
    df <- data.frame(Y, prob.est)
    calPlotData <- caret::calibration(Y ~ prob.est, data = df, class = selClass, cuts = 6)
    P1 <- lattice::xyplot(calPlotData, auto.key = list(columns = 2),
                 main = "Calibration plot")
    print(P1)

    # Histogram comparison
    P2 <- ggplot2::ggplot(df) +
      ggplot2::geom_histogram(ggplot2::aes(x = prob.est, fill = Y), bins = 15) +
      ggplot2::facet_wrap(~Y) +
      ggplot2::labs(x = paste("Probability of Classes"), title = "Probability histograms")
    print(P2)
  }
}
