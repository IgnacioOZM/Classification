#' Generate a dataframe for classification
#'
#' @description Function that creates a dataset of points asssociated to different classes
#' @param nc    \code{integer}, number of classes to generate
#' @param npt   \code{integer}, number of points to generate per click
#' @param sigma \code{numeric} standard deviation of the gaussians used for randomly select points in each click
#' @return dataframe with x1 and x2 values of axis and Y variable with the class
#' @examples fdata <- genmat(nc = 3, npt = 7, sigma = 1)
#' @export GenMat
GenMat <- function(nc, npt, sigma) {
  # Check parameter inputs
  if (is.null(nc))
    stop("Please, input the number of classes (nc)")
  if (is.null(npt))
    stop("Please, input the number of points per click (npt)")
  if (is.null(sigma))
    stop("Please, input the standard deviation for the gaussian distributions (sigma)")

  # ranges
  rx = seq(from = -10,
           to = 10,
           length.out = 100)
  ry = seq(from = -10,
           to = 10,
           length.out = 100)
  xy = expand.grid(X1 = rx, X2 = ry)
  plot(xy,
       pch = ".",
       xlim = range(xy$X1),
       ylim = range(xy$X2))
  simdata = data.frame(X1 = double(), X2 = double(), Y = integer())
  clase = 1
  message(c("Click on the plot to create points of category ", clase))
  message("Press Escape to move on to the next category")
  while (1) {
    sel = identify(xy, n = 1, plot = FALSE)
    if (!length(sel)) {
      if (clase == nc)
        break
      else
        clase = clase + 1
      message("---------------------------------------------------------")
      message(c("Click on the plot to create points of category ", clase))
      message("Press Escape to move on to the next category")
    } else {
      aux = mvtnorm::rmvnorm(npt, mean = as.numeric(xy[sel,]), sigma = sigma *
                               diag(2))
      aux = data.frame(X1 = aux[, 1],
                       X2 = aux[, 2],
                       Y = rep(clase, length(aux[, 1]), 1))
      simdata = rbind(simdata, aux)
    }
    plot(
      x = simdata$X1,
      y = simdata$X2,
      col = simdata$Y,
      pch = 20,
      axes = FALSE,
      xlab = "",
      ylab = "",
      xlim = range(xy$X2),
      ylim = range(xy$X1)
    )
    par(new = TRUE)
    plot(xy,
         pch = ".",
         xlim = range(xy$X1),
         ylim = range(xy$X2))
  }

  # Classes start from 0
  simdata$Y <- simdata$Y - 1
  # Randomize data
  simdata <- simdata[sample.int(length(simdata$Y)),]
  return(simdata)
}
