#' BoxCox Lambda plot
#'
#' @description Plot the analysis of the BoxCox lambda transformation to see if the transformation
#' is necessary and which lambda to use.
#' @param fdata_ts \code{timeserie} to be analyzed
#' @param window.width \code{integer} window of time of the \code{timeserie} to be analyzed
#' @export
BoxCox.lambda.plot <- function(fdata_ts, window.width = frequency(fdata_ts)) {

  if (window.width <  1) {
    stop("Specify a window.width greater than 1")
  }
  if (window.width > length(fdata_ts)) {
    stop("Window.width cannot be greater than the length of the time serie")
  }

  fm <- min(fdata_ts)
  if (fm <= 0) {
    fdata_ts <- fdata_ts - fm + 1
  }

  mm <- matrix(nrow = length(fdata_ts) - window.width + 1, ncol = 1)
  sdm <- matrix(nrow = length(fdata_ts) - window.width + 1, ncol = 1)
  dfm <- data.frame(log.ma = mm, log.sd = sdm)
  for (i in seq(1, length(fdata_ts) - window.width + 1)) {
    dfm$log.ma[i] <- log(mean(fdata_ts[seq(i, i + window.width - 1)]))
    dfm$log.sd[i] <- log(sd(fdata_ts[seq(i, i + window.width - 1)]))
  }

  linmod <- lm(log.sd ~ log.ma, data = dfm)
  r2 <- summary(linmod)$r.squared
  Alpha <- coef(linmod)[2]
  Lambda <- 1 - Alpha

  p <- ggplot2::ggplot(dfm, ggplot2::aes(x = log.ma, y = log.sd)) +
    ggplot2::geom_point() +
    ggplot2::geom_smooth(method = lm) +
    ggplot2::labs(
      title = "Plot for determining the Box-Cox transformation",
      subtitle = paste(
        "Lambda = ",
        round(Lambda, 4),
        "     R-squared = ",
        round(r2, 4),
        "     Window =",
        window.width
      )
    )
  print(p)

  return(Lambda)
}
