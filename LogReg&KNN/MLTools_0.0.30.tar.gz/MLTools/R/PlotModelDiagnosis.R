#' Analyze results of Regression models
#'
#' @description Function which plot the residuals of the regression prediction vs the real value in each of the predictors.
#' It prints all the plots using \code{grid.arrange()}
#' @param expl.Var Dataframe with input variables
#' @param real vector with real values
#' @param pred vector with estimated values
#' @param together \code{logical} if \code{TRUE}, all the graphics are shown together using \code{grid.arrange}. By defaulta
#' is \code{FALSE}
#' @examples
#' plotModelDiagnosis(fdata[, predictors], fdata[, output], fdata[, model_pred])
#' @export PlotModelDiagnosis
PlotModelDiagnosis <- function(expl.Var, real, pred, together = FALSE) {
  if (ncol(expl.Var) > 1) {
    expl.Var <- as.data.frame(expl.Var)
  }
  # Name of variables
  var.names <- colnames(expl.Var)

  # Calculate residuals
  residuals <- real - pred

  aux <- data.frame(real = real,
                    pred = pred,
                    residuals = residuals)
  fdata <- cbind(expl.Var, aux)

  # List to plot all the plots together
  plotlist <- list()
  # histogram of residuals
  plotlist[[1]] <-
    ggplot2::ggplot(fdata) + ggplot2::geom_histogram(ggplot2::aes(x = residuals), bins = 15) +
    ggplot2::labs(title = "histogram of residuals")

  # residual plots
  plotlist[[2]] <-
    ggplot2::ggplot(fdata) + ggplot2::geom_point(ggplot2::aes(x = pred, y = residuals)) +
    ggplot2::geom_smooth(ggplot2::aes(x = pred, y = residuals), method = "loess") +
    ggplot2::labs(title = "Real vs Forecast",
                  xlab = "Fitted",
                  ylab = "residuals")

  # residual vs expl var plot
  for (ii in 1:ncol(expl.Var)) {
    print(paste("Residuals vs ", var.names[ii]))
    if (is.numeric(expl.Var[, ii])) {
      ploti <-
        ggplot2::ggplot(fdata) + ggplot2::geom_point(ggplot2::aes_string(x = var.names[ii], y = "residuals")) +
        ggplot2::geom_smooth(ggplot2::aes_string(x = var.names[ii], y = "residuals"), method = "loess") +
        ggplot2::labs(title = paste("Residuals vs ", var.names[ii]),
                      xlab = var.names[ii])
      plotlist[[ii + 2]] <- ploti

    } else {
      ploti <-
        ggplot2::ggplot(fdata) + ggplot2::geom_boxplot(ggplot2::aes_string(x = var.names[ii], y = "residuals")) +
        ggplot2::labs(title = paste("Residuals vs ", var.names[ii]),
                      xlab = var.names[ii])
      plotlist[[ii + 2]] <- ploti
    }
  }
  # Plot the list of plots created before
  if (together) {
    gridExtra::grid.arrange(grobs = plotlist,
                            nrow = floor(sqrt(length(plotlist))),
                            ncols = ceiling(sqrt(length(plotlist))))
  } else {
    for(i in 1:length(plotlist)){
      print(plotlist[[i]])
    }
  }

}
