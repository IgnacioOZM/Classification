#' Analyze results of ARIMA models
#'
#' @description Plot a geom_line plot, a histogram, the ACF plot and the PACF plot of the time series.
#' @param time.serie \code{timeserie} to be analyzed
#' @param output \code{character} defines which variable is going to be printed. If it's \code{NULL}, the variable
#' printed is the first of the time series which is not the time variable
#' @param spline.degree \code{integer} sets the degree of the regression line adjusted to the geom_line. By default is 5.
#' @param bins \code{integer} sets the bins of the histogram. By default is 15
#' @param lag \code{integer} adjust the ACF and the PACF plots. By default is a tenth of the length of the time series
#' @examples
#' ARIMA.analysis(Arima.fit)
#' @export ARIMA.analysis
ARIMA.analysis <- function(time.serie = NULL,
                           output = NULL,
                           spline.degree = 5,
                           bins = 15,
                           lag = length(time.serie / 10)) {
    if (is.null(time.serie) || !is.ts(time.serie)) {
      # Check if the time serie introduced is valid
      stop("Introduce a correct time serie")
    }
    if (is.null(output) || !(output %in% colnames(time.serie))) {
      # Check if the output has been defined by the user
      if (is.null(ncol(time.serie))) {
        # Check if there are multiple time.series
        data_frame <- data.frame(
          values = as.numeric(time.serie),
          time = seq(1, length(time.serie), 1),
          std = scale(time.serie)[, 1]
        )
      } else{
        data_frame <- data.frame(
          values = as.numeric(time.serie[, 1]),
          time = seq(1, length(time.serie[, 1]), 1),
          std = scale(time.serie[, 1])[, 1]
        )
      }
    } else {
      # The data has been defined by the user
      data_frame <- data.frame(
        values = as.numeric(time.serie$output),
        time = seq(1, length(time.serie$output), 1),
        std = scale(time.serie$output)[, 1]
      )
    }

    #Make the geom_line plot
    plot.line <- ggplot2::ggplot(data_frame, ggplot2::aes(x = time, y = values)) +
      ggplot2::geom_line() +
      ggplot2::geom_smooth(
        method = "lm",
        formula = y ~ splines::bs(x, spline.degree),
        se = FALSE,
        color = 'blue'
      ) +
      ggplot2::ggtitle("Time serie") + xlab("time") + ylab("values")
    #Make the ACF plot
    plot.Acf <- forecast::ggAcf(time.serie, lag.max = lag)
    #Make the PACF plot
    plot.Pacf <- forecast::ggPacf(time.serie, lag.max = lag)
    #Make the histogram plot
    plot.hist <- forecast::gghistogram(
      data_frame$values,
      add.normal = TRUE,
      add.rug = TRUE,
      bins = bins
    ) +
      ggplot2::ggtitle("Distribution") + xlab("Values")

    gridExtra::grid.arrange(plot.line, plot.hist, plot.Acf, plot.Pacf, nrow = 2)
  }
